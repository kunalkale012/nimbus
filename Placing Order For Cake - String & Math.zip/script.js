function OrderCake(str) {
	//fill the code
	return "Your order for "+(parseInt(str.substring(0,4)/1000)+ 1)+" kg "+(str.substring(4,str.length-3))+" cake has been taken. You are requested to pay Rs. "+parseInt(str.substring(0,4)/1000 *450)+" on the order no "+str.substring(str.length-3,str.length);
}